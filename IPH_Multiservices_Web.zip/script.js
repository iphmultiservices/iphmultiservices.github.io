document.getElementById("year").textContent = new Date().getFullYear();

function toggleMenu(){
  document.getElementById("navMenu").classList.toggle("open");
}

let french = false;
function toggleLanguage(){
  french = !french;
  document.querySelector(".lang").textContent = french ? "ES" : "FR";

  const t = french ? {
    heroTitle:"Des solutions professionnelles pour vos projets",
    heroText:"Énergie solaire, installations électriques, informatique, réseaux et design graphique.",
    heroBtn:"Demander des informations",
    servicesTitle:"Nos services",
    s1t:"Énergie solaire", s1p:"Conception et installation de systèmes solaires, onduleurs, batteries et panneaux.",
    s2t:"Électricité", s2p:"Installations électriques, protections et solutions pour les maisons et entreprises.",
    s3t:"Informatique et réseaux", s3p:"Configuration d'ordinateurs, réseaux, serveurs et solutions de connectivité.",
    s4t:"Design graphique", s4p:"Logos, flyers, bannières et supports visuels pour entreprises et projets.",
    projectsTitle:"Projets", projectsText:"Une galerie des installations et travaux réalisés par IPH Multiservices sera bientôt disponible.",
    contactTitle:"Contact", contactText:"Ajoutez vos coordonnées avant de publier le site."
  } : {
    heroTitle:"Soluciones profesionales para tus proyectos",
    heroText:"Energía solar, instalaciones eléctricas, informática, redes y diseño gráfico.",
    heroBtn:"Solicitar información",
    servicesTitle:"Nuestros servicios",
    s1t:"Energía solar", s1p:"Diseño e instalación de sistemas solares, inversores, baterías y paneles.",
    s2t:"Electricidad", s2p:"Instalaciones eléctricas, protecciones y soluciones para viviendas y negocios.",
    s3t:"Informática y redes", s3p:"Configuración de computadoras, redes, servidores y soluciones de conectividad.",
    s4t:"Diseño gráfico", s4p:"Logos, flyers, banners y material visual para empresas y proyectos.",
    projectsTitle:"Proyectos", projectsText:"Próximamente podrás ver aquí una galería de instalaciones y trabajos realizados por IPH Multiservices.",
    contactTitle:"Contacto", contactText:"Completa tus datos de contacto cuando estés listo para publicar la web."
  };

  for(const id in t) document.getElementById(id).textContent = t[id];
}
